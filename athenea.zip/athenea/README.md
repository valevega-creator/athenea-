# Athenea

Sistema de arranque y crecimiento de empresas con Athenea, el cerebro CEO.

Es un sitio estático: todo está en `index.html`.

## Desplegar en Vercel
1. Sube esta carpeta a un repositorio de GitHub.
2. En vercel.com → Add New → Project → importa el repositorio.
3. Framework Preset: **Other**. Sin comando de build. Deploy.

## Probar en local
Abre `index.html` en el navegador.
